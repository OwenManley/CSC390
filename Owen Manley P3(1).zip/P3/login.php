<?php
//Owen Manley, Project #3, CSC 390. This page handles saving a username and password to login to the webpage.
    session_start();
    require('userAuthenticator.php');
    $authenticator = new userAuthenticator();

    if (isset($_POST["login"])){
        //var_dump($_POST);
        //echo "I AM IN IF";
        $username = $_POST['username'];
        $password = $_POST['password'];
        if(($authenticator->authenticate($username, $password)) === true){
            $authenticator->logUserIn($username); //(username: $_POST['username']);
            header("Location: index.php");
            exit();
        }else{
            echo "LOGIN ERROR: Missing/Invalid username and/or password!";
        }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN PAGE</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
<div class='center-screen'>
<div id='login'>
    <h1>Login:</h1>
    <form action="login.php" method="post">
        <label><strong>Username:</strong></label><p><input type="username" name="username"/></p>
        <label><strong>Password:</strong></label><p><input type="password" name="password"/></p>
        <input type="submit" name="login" value="Login"></input>
</form>
</div>
</div>
</body>
</html>
