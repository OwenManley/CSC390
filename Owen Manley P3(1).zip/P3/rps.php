<?php
//Owen Manley, Project #3, CSC 390. This is the rps page.
      session_start();
      require('userAuthenticator.php');
      $loggedIn = new userAuthenticator();
  
      if(!$loggedIn->isLoggedIn()){
          $loggedIn->redirectToLogin();
      }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rock, Paper, Scissors Game Page</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
    <div id="rps">
    <h1>Rock/Paper/Scissors Game</h1>
    <p>
        <strong>Select an option:</strong><br>
        <form action="rps.php" method="post">
        <input type="radio" name="choice" value="rock">Rock<br>
        <input type="radio" name="choice" value="paper">Paper<br>
        <input type="radio" name="choice" value="scissors">Scissors<br>
        <br>
        <input type="submit" name="submit" value="Submit Choice!"><br>
    </p>
        </form>
    </div>
</body>
</html>

<?php
    if (isset($_POST['submit']) && isset($_POST['choice'])){
            $_SESSION['choice'] = $_POST['choice'];
            header("Location: playrps.php");
        }
?>