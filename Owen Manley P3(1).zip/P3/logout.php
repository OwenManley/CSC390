<?php
//Owen Manley, Project #3, CSC 390. This page gives the user the option to log out.
    session_start();
    require('userAuthenticator.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout Page</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
    <div id="index-heading">
    <h2>Logout Page</h2>
    </div>
    <div id="logout-button">
    <form action="logout.php" method="post">
    <input type="submit" name="logout" value="Logout"></input>
    </form>
    </div>
</body>
</html>
<?php
    $loggingOut = new userAuthenticator();
   if (isset($_POST['logout'])){
    $loggingOut->logout();
   }
?>