<?php
//Owen Manley, Project #3, CSC 390. This page is a sentence repeater.
      session_start();
      require('userAuthenticator.php');
      $loggedIn = new userAuthenticator();
  
      if(!$loggedIn->isLoggedIn()){
          $loggedIn->redirectToLogin();
      }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repeater Page</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
<div id='repeater-screen'>
    <form action = "repeater.php" method = "post">
   <p><strong>Input a sentence to repeat:</strong></p>
   <p><input type="text" name = "sentence"/></p> 
   <input type = "submit" name = "Enter" value = "Enter"/>
    </form>
</div>
<div id="repeater-function">
<?php
    $count = 0;
    if(isset($_POST['Enter']) && !empty($_POST['sentence'])){
        $repeater = rand(1,300);
        for($i = 0; $i < $repeater; $i++) {
            echo $_POST['sentence'] . "<br>";
            $count++;
        }
        echo "<br>";
        echo "Sentences repeated: " . $count;
    }
?>
</div>
</body>
</html>

