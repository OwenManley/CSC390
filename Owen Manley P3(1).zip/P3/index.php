<?php
//Owen Manley, Project #3, CSC 390. This is the homepage.
    session_start();
    require('userAuthenticator.php');
    $loggedIn = new userAuthenticator();

    if(!$loggedIn->isLoggedIn()){
        $loggedIn->redirectToLogin();
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
    <div id="index-heading">
    <h1>HomePage:</h1>
    <p>Welcome, <?php echo $_SESSION['username'] ?>!</p>
</div>
    <div class="center-screen">
        <div id="login">
    <a href="logout.php"><p>Logout</p></a>
    <a href="date.php"><p>Date</p></a>
    <a href="rps.php"><p>Play RPS!</p></a>
    <a href="repeater.php"><p>Sentence Repeater</p></a>
        </div>
    </div>
</body>
</html>