<?php
//Owen Manley, Project #3, CSC 390. This page displays the results of the rps game against the CPU.
     session_start();
     require('userAuthenticator.php');
     $loggedIn = new userAuthenticator();
 
     if(!$loggedIn->isLoggedIn()){
         $loggedIn->redirectToLogin();
     }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rock/Paper/Scissors Results</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
    <div id="rps-results">
    <h1>Rock/Paper/Scissors Results!</h1>
    <p>Results for Rock/Paper/Scissors Game!</p><br>

    <?php
    echo "<strong>Player: </strong>" . $_SESSION['choice'] . "<br><br>";

    $choices = ["rock","paper","scissors"];
    $computerChoice = $choices[array_rand($choices)];

    echo "<strong>CPU: </strong>" . $computerChoice . "<br><br>";

    if($_SESSION['choice'] === $computerChoice){
        echo "<strong>" . "Results: " . "</strong>" . "It's a tie!";
    }elseif(($_SESSION['choice'] === 'rock' && $computerChoice === 'scissors') ||
            ($_SESSION['choice'] === 'paper' && $computerChoice === 'rock') ||
            ($_SESSION['choice'] === 'scissors' && $computerChoice === 'paper')){
                
                echo "<p><strong>Results:</strong> You win!</p>";
            }else{
                echo "<p><strong>Results:</strong> Computer wins :(!</p>";
            }

    if(isset($_POST['playAgain'])){
        header("Location: rps.php");
        exit();
    }
?>
     </div>
    <br>
     <form action = "playrps.php" method = "post">
    <input type="submit" name="playAgain" value="Play Again?"><br>
    </form>
</body>
</html>
