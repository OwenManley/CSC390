<?php
//Owen Manley, Project #3, CSC 390. This is the main page where all authentication takes place.
class userAuthenticator{
//Constants set to accept a hardcoded user and password.
    const USERNAME = 'admin';
    const PASSWORD = 'password';
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Returns the username in the session.
    public function isLoggedIn(): bool{
        return isset($_SESSION['username']);
    }//end isLoggedIn
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//Sets the username and password that was entered into the constants.
    public function authenticate($username, $password): bool{
        return $username === self::USERNAME && $password === self::PASSWORD;
    }//end authenticate
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//This function should handle logging the user into the website.    
   public function logUserIn($username): void{
        //require("login.php");
        $_SESSION['username'] = $username;
    }//end logUserIn
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//When the button is pressed on the logout page, this function is called which destroys the session. This redirects the user back to the login page with the username and
//password unsaved in the process.
   public function logout(): void{
        session_destroy();
        $_SESSION = array(); //Not entirely sure what this does, but kept it because it doesn't hurt anything.
        header("Location: login.php");
        exit();
    }//end logout
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//If a user somehow gets to another page without going through the login process, they get directed to login.php.
   public function redirectToLogin(): void{
        header("Location: login.php");
        exit();
    }//end redirectToLogin
}//end userAuthenticator
?>
