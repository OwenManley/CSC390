<?php
//Owen Manley, Project #3, CSC 390. This page displays the current date.
    session_start();
    require('userAuthenticator.php');
    $loggedIn = new userAuthenticator();

    if(!$loggedIn->isLoggedIn()){
        $loggedIn->redirectToLogin();
    }
    $currentDateTime = date("m/d/Y h:i A");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Date Page</title>
    <link href = "style.css" type = "text/css" rel = "stylesheet">
</head>
<body>
<div id="index-heading">
    <h1>Current Time & Date:</h1>
    <p><?php echo $currentDateTime; ?></p>
</div>
</body>
</html>